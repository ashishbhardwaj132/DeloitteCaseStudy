/**
 * 
 */
package org.deloitte.digital.serviceImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.deloitte.digital.service.ActivityService;
import org.deloitte.digital.utilities.ActivityConstants;
import org.deloitte.digital.utilities.ActivityUtility;

/**
 * @author ashibhardwaj
 * This Service Layer class handles the controller calls and return 
 * || evaluate the data based on the timings of presentation.
 *
 */
public class ActivityServiceImpl implements ActivityService,ActivityConstants { 
	Map<String,String> properties = null;
	public ActivityServiceImpl(){
		// Load property File In-Memory
		properties = ActivityUtility.loadProperties();
	}

	/***
	 * @author ashibhardwaj
	 * @param Integer
	 * @param List<List<Integer>>
	 * @throws Exception
	 * This method evaluates the best Slot time 9 AM to 12 PM || 1 PM to 4 PM
	 * & return the best the best slot for the presentation.
	 */
	@Override
	public  Integer bestSlotByTime(Integer presentationMinutes, List<List<Integer>> stack) throws Exception{
		List<Integer> best=null;
		int numberOfSlots = 2;
		
		try {
			int least = ActivityUtility.sumOfSlots(stack.get(0));

			if(least+presentationMinutes <= TOTALEVENING)
				best=stack.get(0);
			if(ActivityUtility.sumOfSlots(stack.get(1)) < least 
					&& ActivityUtility.sumOfSlots(stack.get(1)) + presentationMinutes <=  TOTALEVENING){
				least = ActivityUtility.sumOfSlots(stack.get(1));
				best = stack.get(1);
			}
			if(best==null)
				numberOfSlots=4;
			if(numberOfSlots > 2){
				if(ActivityUtility.sumOfSlots(stack.get(2)) + presentationMinutes <=  TOTALMORNING){
					least = ActivityUtility.sumOfSlots(stack.get(2));
					best = stack.get(2);
				}
				if(ActivityUtility.sumOfSlots(stack.get(3)) + presentationMinutes <= TOTALMORNING){
					least = ActivityUtility.sumOfSlots(stack.get(3));
					best = stack.get(3);
				}
			}
		} catch (Exception e) {
			throw new Exception("Error while bestSlotByTime" + e);
		}
		return stack.indexOf(best);
	}
	
	/**
	 * @author ashibhardwaj
	 * @param List<String>
	 * @param List<List<Integer>>
	 * This method triggers the printing format based on the slot selected by bestSlotByTime()
	 * & return the String with output formatted.
	 */
	@Override
	public StringBuilder arrangeActivityBySlot(List<String> activities, List<List<Integer>> slotArrangement)
			throws Exception {
		StringBuilder arrangements = new StringBuilder(); 

		try {
			arrangements.append(NEXT_LINE+properties.get(FIRST_TEAM_NAME)+NEXT_LINE);
			activities = printActivity(activities, slotArrangement, arrangements, 2);

			arrangements.append(NEXT_LINE+properties.get(SECOND_TEAM_NAME)+NEXT_LINE);
			printActivity(activities, slotArrangement, arrangements, 3);
		} catch (Exception e) {
			throw new Exception("Error while arrangeActivityBySlot" + e);
		}
		return arrangements;
	}
	/**
	 * @author ashibhardwaj
	 * @param activities
	 * @param slotArrangement
	 * @param arrangements
	 * @param index
	 * This method iterate over the slots and return the output with formated timings
	 */
	private List<String> printActivity(List<String> activities, List<List<Integer>> slotArrangement
			,StringBuilder arrangements, int index) throws Exception{

		LocalTime sixThirty = LocalTime.parse(START_TIME);
		LocalTime noon = LocalTime.parse(LUNCH_TIME);

		try {
			DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(TIMINGS_FORMAT);
			int startTime = 0;
			for(; index >= 0; index=index-2){
				// If timings have gap before lunch, Start the first presentation after Gap minutes
				if(index == 2 || index == 3){
					startTime =  ActivityConstants.TOTALMORNING - ActivityUtility.sumOfSlots(slotArrangement.get(index));
					sixThirty = sixThirty.plusMinutes(startTime); 
				}

				for(Integer value : slotArrangement.get(index)){ 
					activities = activities.stream().map(x -> x.replaceAll(SPRINT, properties.get(SPRINT_TIME)))
							.collect(Collectors.toList());
					String activityName = activities.stream().filter(p -> p.contains(value+MINUTES)).findFirst().get();
					int indexOfActivity = activities.indexOf(activityName);
					if(noon.equals(sixThirty)){
						arrangements.append(sixThirty.format(dateFormat));
						arrangements.append(" : ");
						arrangements.append(LUNCH_BREAK+NEXT_LINE);
						sixThirty = sixThirty.plusMinutes(SIXTY_MINUTES); 
					}
					arrangements.append(sixThirty.format(dateFormat));
					arrangements.append(" : ");
					arrangements.append(activityName.contains(properties.get(SPRINT_TIME))
							?activityName.replaceAll(properties.get(SPRINT_TIME), SPRINT):activityName);
					arrangements.append(NEXT_LINE);
					activities.remove(indexOfActivity);
					sixThirty = sixThirty.plusMinutes(value); 

				}
			}
			arrangements.append(sixThirty.format(dateFormat));
			arrangements.append(COLON);
			arrangements.append(properties.get(STAFF_ACTIVITY_NAME));
			arrangements.append(NEXT_LINE);
		} catch (Exception e) {
			throw new Exception("Error while printActivity" + e);
		}
		return activities;
	}

	/**
	 * @author ashibhardwaj
	 * @exception FileNotFoundException
	 * This method read the input file from the System Directory and prepare the LIST
	 * @throws URISyntaxException 
	 */
	@Override
	public List<String> readInputFile() throws FileNotFoundException,IOException, URISyntaxException { 
		List<String> activity = new ArrayList<>();

		InputStream input =ActivityUtility.class.getClassLoader().getResourceAsStream(properties.get(INPUT_FILE_NAME));
		
		 try (BufferedReader buffer = new BufferedReader(new InputStreamReader(input))) {
			 activity = buffer.lines().collect(Collectors.toList());
	     } catch (FileNotFoundException e) {
			throw new IOException("Error FileNotFoundException while readInputFile" + e);
		}catch (IOException e) {
			throw new IOException("Error IOException while readInputFile " + e);
		}
		return activity;
	}

	/**
	 * @author ashibhardwaj
	 * @param data
	 * @exception IOException
	 * This method write the file with all the presentation slots with timings.
	 * 
	 */
	@Override
	public boolean writeFile(String data) throws IOException {
		boolean exported = false;
		try{
			new File(properties.get(OUTPUT_FILE_PATH)).mkdirs();
			Files.write(Paths.get(properties.get(OUTPUT_FILE_PATH)
					+properties.get(ActivityConstants.OUTPUT_FILE_NAME)), data.getBytes());
			exported = true;
		}catch(IOException ioException){
			throw new IOException(EXCEPTION_FILE_EXPORT);
		}

		return exported;
	}

}
