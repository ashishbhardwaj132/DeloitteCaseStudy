/**
 * This file handles the controller layer flow of Deloitte Digital Away Day
 *  
 */
package org.deloitte.digital.controller;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.deloitte.digital.service.ActivityService;
import org.deloitte.digital.serviceImpl.ActivityServiceImpl;
import org.deloitte.digital.utilities.ActivityUtility;

/**
 * @author ashibhardwaj
 * This controller contains entry method which internally calls service layer methods to
 * evaluate the activity time slots
 */
public class ActivityController {

	//Service Injection from Controller
	static ActivityService serviceInjection = new ActivityServiceImpl();
	private static List<List<Integer>> listOfSlots = new ArrayList<>(); 

	/**
	 * @param args
	 * This main(args) method is the entry point the application.
	 */
	public static void main(String[] args) throws Exception{

		List<String> activity = null;
		List<String> activityNameShuffle = null;
		try {
			//Initialize the Slots
			ActivityUtility.initalizeStack(listOfSlots);
			//read the file from the  path and load the data in the list
			activity = serviceInjection.readInputFile();
			/*
			 * Shuffle and sort the timings based on the DESC order of the Presentation timings
			 * Example: 60 minutes presentation at the top & sprint in the end to evaluate 
			 * 			the activity using Greedy Selection Algorithm
			 */
			
			activityNameShuffle = ActivityUtility.shuffleAndSortActivity(activity);
			// Iterate the Activity and based on the time find the best slot for it.
			for (String time : activityNameShuffle) {
				Integer timinigs = ActivityUtility.getTimeByActivityList(time);
				// calling the method to find the best Slot  for the presentation.
				int slotIndex = serviceInjection.bestSlotByTime(timinigs, listOfSlots);
				// Add the presentation in the best slot.
				listOfSlots.get(slotIndex).add(timinigs);
			}
			// arranging the activities and prepare the output file data
			StringBuilder str = serviceInjection.arrangeActivityBySlot(activity, listOfSlots); 
			// Write file to the path configured in configuration.properties
			boolean result = serviceInjection.writeFile(str.toString());
			
			if(result){
				System.out.println("Operation Successfully Completed. Please Go to C:\\deloitte_digital");
			}else{
				System.out.println("Operation failed"); 
			}

		} catch (FileNotFoundException e3) {
			throw new Exception(e3.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}

	}
}
