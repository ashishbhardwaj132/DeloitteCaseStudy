/**
 * 
 */
package org.deloitte.digital.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

/**
 * @author ashibhardwaj
 * Interface used in the service layer flow.
 */
public interface ActivityService {
	
	public  Integer bestSlotByTime(Integer presentationMinutes, List<List<Integer>> stack) throws Exception;
	public StringBuilder arrangeActivityBySlot(List<String> activities, List<List<Integer>> slotArrangement) throws Exception;
	public List<String> readInputFile() throws FileNotFoundException,IOException,URISyntaxException;
	public boolean writeFile(String data) throws IOException;

}
